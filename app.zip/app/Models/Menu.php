<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    //
    protected $table = 't_system_function';
    protected $primaryKey = 'pk_i_id';
}
