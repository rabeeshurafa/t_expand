<?php

namespace App\Models;

namespace App\Models;
use App\Casts\Json;
use Illuminate\Database\Eloquent\Model;
class Merge extends Model
{
    

}
