<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class jobLic extends Model
{
    protected $table = 'joblic';
}
