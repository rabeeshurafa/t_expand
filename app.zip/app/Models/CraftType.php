<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CraftType extends Model
{
    //
}
