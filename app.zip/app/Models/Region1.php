<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Region1 extends Model
{
    protected $table = 'regions1';
    protected $primaryKey = 'region_id';
}
