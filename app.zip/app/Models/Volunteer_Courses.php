<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Volunteer_Courses extends Model
{
    //
}
