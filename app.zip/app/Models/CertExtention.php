<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CertExtention extends Model
{
    //
    protected $table = 't_certification';
    protected $primaryKey = 'pk_i_id';
}
